#!/bin/sh
epydoc --name="Yokadi" --html --graph=all -o doc *py
