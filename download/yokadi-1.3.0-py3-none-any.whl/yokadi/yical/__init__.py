# -*- coding: utf-8 -*-
"""
Yokadi ical daemon package
@author: Aurélien Gâteau <mail@agateau.com>
@author: Sébastien Renard <sebastien.renard@digitalfox.org>
@license:GPL v3 or later
"""
