# Debugging

## Show SQL commands

If you set the `YOKADI_SQL_DEBUG` environment variable to a value different
from "0", all SQL commands will be printed to stdout.
