# -*- coding: utf-8 -*-
"""
Yokadi command line interface package
@author: Aurélien Gâteau <aurelien.gateau@free.fr>
@author: Sébastien Renard <sebastien.renard@digitalfox.org>
@license:GPL v3 or later
"""
