# -*- coding: utf-8 -*-
"""
Yokadi main package
@author: Aurélien Gâteau <aurelien.gateau@free.fr>
@author: Sébastien Renard <sebastien.renard@digitalfox.org>
@license:GNU GPL V3
"""