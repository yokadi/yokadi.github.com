# -*- coding: utf-8 -*-
"""
Yokadi main package
@author: Aurélien Gâteau <mail@agateau.com>
@author: Sébastien Renard <sebastien.renard@digitalfox.org>
@license:GPL v3 or later
"""

__version__ = "1.1.0"
